=== カスタムCSS/JS per Post ===
Contributors: Nagaoka Design Office
Tags: css, javascript, post, plugin
Requires at least: 5.0
Tested up to: 6.9
Stable tag: 1.0.0
Requires PHP: 7.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

投稿記事ごとにカスタムのCSS、JavaScriptを追加できるプラグインです。

== Description ==

投稿・固定ページごとに個別の CSS / JavaScript を追加できます。

== Installation ==

1. Upload `custom-css-js-per-post.php` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' screen in WordPress

== Changelog ==

= 1.0.0 =
- 初回リリース
